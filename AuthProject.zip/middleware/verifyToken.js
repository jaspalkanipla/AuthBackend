import jwt from "jsonwebtoken";
export const verifyToken = (req, res, next) => {
  const t = req.headers.cookie.split("=")[1]
  const token=t.split(";")[0]
  // console.log(token)
  // const userCookie = req.cookies;
  // console.log(userCookie["r@gmail.com"]);
  // res.send(token)

  console.log(token)
  if (token) {
    jwt.verify(token, process.env.SECRET_KEY, (err, user) => {
      if (err) {
        res.status(500).send({ message: "token not verified" });
      } else {
        //   const { userEmail } = user;
        // console.log("token verfied");
        req.userEmail = user.userEmail;
      }
    });
    next();
  } else {
    res.status(500).send({ message: "token not found" });
  }
};
