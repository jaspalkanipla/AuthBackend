export const home = async (req, res) => {
//   res.cookie("name", "value");
  let a=res.cookie("rememberme", "1", {
    expires: new Date(Date.now() + 900000),
    httpOnly: true,
    path:"/"
  });
//   console.log(a);



  res.status(200).send("hello");
};
