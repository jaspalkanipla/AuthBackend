import User from "../models/userSignup.js";

export const getUser = async (req, res) => {
  try {
    const data = await User.findOne({ userEmail: req.userEmail });
    if (data) {
      res.status(200).send({ data: data });
    } else {
      res.status(404).send({ message: "data not found" });
    }
  } catch (error) {
    console.log(error);
  }
  //   const {} = res.send({ message: "authenticated", email: req.userEmail });
};
