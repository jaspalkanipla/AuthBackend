import User from "./../models/userSignup.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
export const signIn = async (req, res) => {
  try {
    const { userEmail, userPass } = req.body;
    const data = await User.findOne({ userEmail });

    if (data) {
      const isMatch = await bcrypt.compare(userPass, data.userPass);
      if (isMatch) {
        //PENDING
        const token = jwt.sign(
          { userEmail: data.userEmail },
          process.env.SECRET_KEY,
          { expiresIn: "1d" }
        );
        //PENDING
        // console.log(typeof data.userEmail );
        res.cookie(data.userEmail, token, {
          path: "/",
          httpOnly: true,
          sameSite: "lax",
          secure: false,
        });
        res.status(200).send({ message: "login success", token: token });
      } else {
        res.status(404).send({ message: "password mismatch" });
      }
    } else {
      res.status(404).send({ message: "user not found" });
    }
  } catch (error) {
    console.log(error);
  }
};
